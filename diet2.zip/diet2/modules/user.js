const mongo=require("mongoose")
const { type } = require("os")
const { Timestamp } = require("bson")
const usersheme=new mongo.Schema({
    name:{type:String,required:true},
    email:{
        type:String,
        required:true,
        unique:true
    },password:{
        type:String,
        required:true

    }
},{timestamps:true})
const User=mongo.model("user",usersheme)
module.exports=User