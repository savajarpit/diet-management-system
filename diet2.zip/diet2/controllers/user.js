const USER=require("../modules/user")
const {v4:uuidv4}=require("uuid");
const { setUser } = require("../service/auth");

async function handelusersignup(req,res){
    const result=req.body;
    const finduser=await  USER.findOne({password:result.password,email:result.email})
    if(finduser){return res.render("signup",{err:"something went wrog!!"})}
    await USER.create({
        name:result.name,
        email:result.email,
        password:result.password
    });
    return res.redirect("/")
}
async function handeluserlogin(req,res){
    const result=req.body;
    const finduser=await  USER.findOne({password:result.password,email:result.email})
    if(finduser){
       
      const token= setUser(finduser)
        res.cookie("uid",token)
        res.redirect("/")
    }else{
        return res.render("login")
    }
}


module.exports={
    handelusersignup,handeluserlogin
}