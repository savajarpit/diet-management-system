document
  .getElementById("loginForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    let role = document.getElementById("role").value;

    // Simulating a simple authentication logic
    if (username === "admin" && password === "admin" && role === "admin") {
      // Redirect to admin dashboard or perform admin-specific tasks
      alert("Welcome Admin!");
      // Example: window.location.href = 'admin_dashboard.html';
    } else if (username === "user" && password === "user" && role === "user") {
      // Redirect to user dashboard or perform user-specific tasks
      alert("Welcome User!");
      // Example: window.location.href = 'user_dashboard.html';
    } else {
      // Display error message
      document.getElementById("loginMessage").textContent =
        "Invalid username, password, or role.";
    }
  });
