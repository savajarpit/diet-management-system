const express=require("express")
const {handelusersignup,handeluserlogin}=require("../controllers/user")
const router=express.Router()
router.post('/signup',handelusersignup)
router.post('/login',handeluserlogin)
module.exports=router