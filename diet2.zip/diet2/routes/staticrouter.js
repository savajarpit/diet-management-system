const express=require("express")
// const URL=require("../modules/url")
const {checkauth}=require("../middlewares/auth")
const router=express.Router()
router.get('/',checkauth,async(req,res)=>{
    // if(!req.users)return res.redirect("signup")
    // const alluser=await URL.find({createdBy:req.users._id}) 
    // return res.render("home",{
    //     urls:alluser
    // })
    res.render("home")
})
router.get("/signup",(req,res)=>
{
 return res.render("signup")
}
)
router.get("/login",(req,res)=>
    {
     return res.render("login")
    }
    )
module.exports=router
