const express=require("express")
const staticrouter=require('./routes/staticrouter')
const connect=require('./connect')
const dejs=require("ejs")
const userrout=require("./routes/user")
const cookieParser=require("cookie-parser")

const app=express()
const path=require("path")
const port=8000;

app.use(cookieParser())
app.use(express.urlencoded({extended:false}))
app.use(express.json())
connect('mongodb://localhost:27017/diet').then(()=>{console.log("mongodb connected")})

app.set("view engine","ejs")
app.set("views",path.resolve("./views"))

// app.get("/signup",(req,res)=>{
//   res.send("signup")
// })
// app.use("/",userrout)
//app.use('/',staticrouter)
// app.use("/",userrout)

app.use("/",userrout)
app.use('/',staticrouter)
app.listen(8000)